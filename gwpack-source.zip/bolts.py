"""Текстуры снарядов заклинаний gwspells: светящиеся «объёмные» шары и лучи (billboard 128x128)."""
import os, sys
import numpy as np
from PIL import Image

N = 128
rng = np.random.default_rng(7)


def noise(scale, seed):
    r = np.random.default_rng(seed)
    g = r.random((scale, scale))
    img = Image.fromarray((g * 255).astype('uint8')).resize((N, N), Image.BICUBIC)
    return np.asarray(img, dtype=float) / 255.0


def fbm(seed):
    return 0.5 * noise(4, seed) + 0.3 * noise(8, seed + 1) + 0.2 * noise(16, seed + 2)


yy, xx = np.mgrid[0:N, 0:N]
cx = cy = (N - 1) / 2
dx, dy = (xx - cx) / (N / 2), (yy - cy) / (N / 2)
rad = np.sqrt(dx ** 2 + dy ** 2)


def sphere(core, mid, edge, rim, radius=0.52, glow=0.95, swirl=0.35, seed=1, hot=(1, 1, 1)):
    R = radius
    inside = rad < R
    z = np.sqrt(np.clip(1 - (rad / R) ** 2, 0, 1))                 # высота точки сферы
    nx, ny, nz = dx / R, -dy / R, z
    L = np.array([-0.45, 0.55, 0.70]); L /= np.linalg.norm(L)
    lam = np.clip(nx * L[0] + ny * L[1] + nz * L[2], 0, 1)
    sw = fbm(seed)
    t = np.clip(0.25 + 0.75 * lam + swirl * (sw - 0.5), 0, 1)
    c0, c1, c2 = (np.array(c, float) / 255 for c in (edge, mid, core))
    col = np.where(t[..., None] < 0.5, c0 + (c1 - c0) * (t[..., None] / 0.5), c1 + (c2 - c1) * ((t[..., None] - 0.5) / 0.5))
    spec = np.clip(nx * (-0.2) + ny * 0.3 + nz * 0.93, 0, 1) ** 24                 # блик
    col = col + spec[..., None] * np.array(hot) * 0.9
    fres = (1 - z) ** 2.2                                                           # свет по краю
    col = col + fres[..., None] * (np.array(rim, float) / 255) * 0.9
    sph_a = np.where(inside, 1.0, 0.0)
    edge_soft = np.clip((R - rad) / 0.04, 0, 1)
    a_sphere = sph_a * edge_soft
    # внешнее свечение
    halo = np.exp(-((np.clip(rad - R, 0, None)) / 0.16) ** 1.4) * glow
    halo = halo * np.clip((0.98 - rad) / 0.25, 0, 1)
    hcol = (np.array(rim, float) / 255) * 0.8 + (np.array(mid, float) / 255) * 0.2
    out = np.zeros((N, N, 4))
    a = np.clip(a_sphere + halo * (1 - a_sphere), 0, 1)
    rgb = (col * a_sphere[..., None] + hcol * (halo * (1 - a_sphere))[..., None]) / np.maximum(a[..., None], 1e-4)
    out[..., :3] = np.clip(rgb, 0, 1)
    out[..., 3] = a
    return out


def rays():
    out = np.zeros((N, N, 4))
    ang = np.arctan2(dy, dx)
    r = rad
    star = np.zeros_like(r)
    for k in range(8):
        a0 = k * np.pi / 4
        d = np.abs(((ang - a0 + np.pi) % (2 * np.pi)) - np.pi)
        width = 0.10 if k % 2 == 0 else 0.06
        length = 0.98 if k % 2 == 0 else 0.62
        beam = np.exp(-(d / width) ** 2) * np.clip(1 - r / length, 0, 1) ** 1.3
        star = np.maximum(star, beam)
    core = np.exp(-(r / 0.22) ** 2)
    ring = np.exp(-((r - 0.62) / 0.04) ** 2) * 0.45
    v = np.clip(star * 0.9 + core * 0.9 + ring, 0, 1)
    out[..., :3] = 1.0
    out[..., 3] = v
    return out


def save(arr, path):
    img = Image.fromarray((np.clip(arr, 0, 1) * 255).astype('uint8'), 'RGBA')
    img.save(path)
    return img


KINDS = {
    #  core,        mid,        edge,       rim
    'fire':   dict(core=(255, 244, 150), mid=(255, 140, 20), edge=(160, 30, 0), rim=(255, 120, 30), seed=11),
    'frost':  dict(core=(245, 255, 255), mid=(130, 205, 250), edge=(40, 100, 200), rim=(150, 220, 255), seed=21),
    'arcane': dict(core=(255, 220, 255), mid=(190, 90, 255), edge=(80, 20, 160), rim=(210, 130, 255), seed=31),
    'shadow': dict(core=(160, 90, 220), mid=(70, 25, 120), edge=(15, 5, 35), rim=(150, 60, 220), seed=41, hot=(0.6, 0.4, 0.9)),
    'holy':   dict(core=(255, 255, 235), mid=(255, 225, 120), edge=(215, 150, 30), rim=(255, 240, 160), seed=51),
    'nature': dict(core=(230, 255, 170), mid=(90, 200, 60), edge=(20, 100, 30), rim=(150, 240, 90), seed=61),
    'arrow':  dict(core=(255, 255, 255), mid=(200, 210, 225), edge=(90, 100, 120), rim=(190, 215, 255), seed=71, radius=0.40, glow=0.7),
}

if __name__ == '__main__':
    out = sys.argv[1]
    os.makedirs(out, exist_ok=True)
    imgs = []
    for k, kw in KINDS.items():
        imgs.append((k, save(sphere(**kw), os.path.join(out, f'bolt_{k}.png'))))
    imgs.append(('rays', save(rays(), os.path.join(out, 'bolt_rays.png'))))
    sheet = Image.new('RGBA', (N * len(imgs), N), (24, 24, 32, 255))
    for i, (k, im) in enumerate(imgs):
        sheet.alpha_composite(im, (i * N, 0))
    sheet.save('bolts_preview.png')
