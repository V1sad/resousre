"""Мини-библиотека: 3D-модели предметов Minecraft из прямоугольных блоков с общей палитрой цветов."""
import json

PALETTE = {}  # "#rrggbb" -> индекс
GRID = 32     # палитра 32x32 пикселей, по пикселю на цвет


def color_index(hex_color):
    hex_color = hex_color.lower()
    if hex_color not in PALETTE:
        if len(PALETTE) >= GRID * GRID:
            raise ValueError("палитра переполнена")
        PALETTE[hex_color] = len(PALETTE)
    return PALETTE[hex_color]


def uv_for(hex_color):
    i = color_index(hex_color)
    px, py = i % GRID, i // GRID
    s = 16.0 / GRID                       # размер пикселя в единицах uv (0..16)
    return [round(px * s + s * 0.25, 4), round(py * s + s * 0.25, 4),
            round(px * s + s * 0.75, 4), round(py * s + s * 0.75, 4)]


def shade(hex_color, k):
    h = hex_color.lstrip('#')
    r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    f = lambda v: max(0, min(255, int(round(v * k))))
    return '#%02x%02x%02x' % (f(r), f(g), f(b))


class Model:
    """kind: 'diag' (оружие в руке, нарисовано вертикально и повёрнуто на 45°), 'upright' (броня, предметы на подставке),
    'offhand' (предмет в левой руке: книга, кристалл), 'shield'."""

    def __init__(self, kind='upright'):
        self.kind = kind
        self.boxes = []   # (x1,y1,z1,x2,y2,z2,color,rot)

    def box(self, x1, y1, z1, x2, y2, z2, col, rot=None):
        if x1 > x2: x1, x2 = x2, x1
        if y1 > y2: y1, y2 = y2, y1
        if z1 > z2: z1, z2 = z2, z1
        self.boxes.append((x1, y1, z1, x2, y2, z2, col, rot))
        return self

    def mirror_x(self, x1, y1, z1, x2, y2, z2, col):
        """Коробка и её зеркальное отражение относительно центра x=8."""
        self.box(x1, y1, z1, x2, y2, z2, col)
        self.box(16 - x2, y1, z1, 16 - x1, y2, z2, col)
        return self

    def elements(self):
        out = []
        for (x1, y1, z1, x2, y2, z2, col, rot) in self.boxes:
            uv = uv_for(col)
            face = {"uv": uv, "texture": "#p"}
            el = {"from": [round(x1, 3), round(y1, 3), round(z1, 3)],
                  "to": [round(x2, 3), round(y2, 3), round(z2, 3)],
                  "faces": {k: dict(face) for k in ("north", "east", "south", "west", "up", "down")}}
            if self.kind == 'diag':
                el["rotation"] = {"origin": [8, 8, 8], "axis": "z", "angle": -45}
            elif rot:
                el["rotation"] = {"origin": rot[2], "axis": rot[0], "angle": rot[1]}
            out.append(el)
        return out

    def display(self):
        if self.kind == 'diag':
            return {
                "thirdperson_righthand": {"rotation": [0, -90, 55], "translation": [0, 4.0, 0.5], "scale": [0.85, 0.85, 0.85]},
                "thirdperson_lefthand": {"rotation": [0, 90, -55], "translation": [0, 4.0, 0.5], "scale": [0.85, 0.85, 0.85]},
                "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
                "firstperson_lefthand": {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
                "gui": {"rotation": [20, -30, 0], "translation": [0, 0, 0], "scale": [0.8, 0.8, 0.8]},
                "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
                "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.9, 0.9, 0.9]},
            }
        if self.kind == 'shield':
            return {
                "thirdperson_righthand": {"rotation": [0, 180, 0], "translation": [0, 3, 2], "scale": [0.8, 0.8, 0.8]},
                "thirdperson_lefthand": {"rotation": [0, 180, 0], "translation": [0, 3, 2], "scale": [0.8, 0.8, 0.8]},
                "firstperson_righthand": {"rotation": [0, 180, 0], "translation": [3, 1, -1], "scale": [0.7, 0.7, 0.7]},
                "firstperson_lefthand": {"rotation": [0, 180, 0], "translation": [-3, 1, -1], "scale": [0.7, 0.7, 0.7]},
                "gui": {"rotation": [15, -35, 0], "translation": [0, 0, 0], "scale": [0.85, 0.85, 0.85]},
                "ground": {"rotation": [0, 0, 0], "translation": [0, 2, 0], "scale": [0.5, 0.5, 0.5]},
                "fixed": {"rotation": [0, 180, 0], "translation": [0, 0, 0], "scale": [0.9, 0.9, 0.9]},
            }
        # upright / offhand: как блок, поворот 30/225 в инвентаре
        return {
            "thirdperson_righthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.55, 0.55, 0.55]},
            "thirdperson_lefthand": {"rotation": [0, 0, 0], "translation": [0, 3, 1], "scale": [0.55, 0.55, 0.55]},
            "firstperson_righthand": {"rotation": [0, 45, 0], "translation": [0, 2.5, 0], "scale": [0.45, 0.45, 0.45]},
            "firstperson_lefthand": {"rotation": [0, 225, 0], "translation": [0, 2.5, 0], "scale": [0.45, 0.45, 0.45]},
            "gui": {"rotation": [30, 225, 0], "translation": [0, 0, 0], "scale": [0.68, 0.68, 0.68]},
            "head": {"rotation": [0, 0, 0], "translation": [0, 13, 0], "scale": [1.0, 1.0, 1.0]},
            "ground": {"rotation": [0, 0, 0], "translation": [0, 3, 0], "scale": [0.4, 0.4, 0.4]},
            "fixed": {"rotation": [0, 0, 0], "translation": [0, 0, 0], "scale": [0.6, 0.6, 0.6]},
        }

    def to_json(self, texture="gw:item/palette"):
        return {"textures": {"p": texture, "particle": texture},
                "elements": self.elements(), "display": self.display()}
