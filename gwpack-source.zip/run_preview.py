import sys, json
import designs
from preview import sheet
D = designs.build_all()
D['rogue_art_blades'] = designs.twin_blades()
names = list(D.keys())
models = [(n, D[n].to_json()) for n in names]
view = sys.argv[1] if len(sys.argv) > 1 else 'gui'
sheet(models[:18], f'sheet1_{view}.png', cols=6, view=view)
sheet(models[18:], f'sheet2_{view}.png', cols=6, view=view)
print(len(models), 'models; palette colors:', len(__import__('gwmodel').PALETTE))
