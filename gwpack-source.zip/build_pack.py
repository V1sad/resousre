"""Собирает ресурс-пак GWinterhold-3D: 3D-модели 36 предметов классов (CustomModelData из items.yml)."""
import json, os, shutil, sys, zipfile
import yaml
from PIL import Image
import designs, gwmodel
from designs import bow, crossbow, DARK, DARKER, GOLD, LIME, WOOD_L, WOOD_D, ICE_L, ICE

ITEMS = sys.argv[1]
OUT = sys.argv[2]
cfg = yaml.safe_load(open(ITEMS, encoding='utf-8'))['items']
D = designs.build_all()
D['rogue_art_blades'] = designs.twin_blades()
missing = [k for k in cfg if k not in D]
extra = [k for k in D if k not in cfg]
assert not missing and not extra, (missing, extra)

shutil.rmtree(OUT, ignore_errors=True)
mdir = os.path.join(OUT, 'assets', 'gw', 'models', 'item')
os.makedirs(mdir)
os.makedirs(os.path.join(OUT, 'assets', 'gw', 'textures', 'item'))
os.makedirs(os.path.join(OUT, 'assets', 'minecraft', 'models', 'item'))

def dump(path, obj):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=1)

# модели предметов
for name, m in D.items():
    dump(os.path.join(mdir, name + '.json'), m.to_json())
# натянутые варианты лука
BOW_ID = 'hunter_leg_bow'
for i, p in enumerate((1.5, 3.0, 4.5)):
    dump(os.path.join(mdir, f'{BOW_ID}_pulling_{i}.json'),
         bow(WOOD_L, WOOD_D, ICE_L, glow=ICE, pull=p).to_json())

# базовые модели ванильных предметов с переопределением по CustomModelData
HAND = {  # parent
    'diamond_axe': 'item/handheld', 'netherite_sword': 'item/handheld', 'diamond_sword': 'item/handheld',
    'iron_sword': 'item/handheld', 'iron_axe': 'item/handheld',
    'stick': 'item/handheld_rod', 'blaze_rod': 'item/handheld_rod',
}
LEATHER = {'leather_helmet', 'leather_chestplate', 'leather_leggings', 'leather_boots'}

by_mat = {}
for name, it in cfg.items():
    by_mat.setdefault(it['material'].lower(), []).append((it['model'], name))

def ov(cmd, model, extra=None):
    pred = {"custom_model_data": cmd}
    if extra: pred.update(extra)
    return {"predicate": pred, "model": model}

for mat, lst in by_mat.items():
    lst.sort()
    overrides = []
    if mat in HAND:
        base = {"parent": HAND[mat], "textures": {"layer0": f"item/{mat}"}}
    elif mat in LEATHER:
        base = {"parent": "item/generated", "textures": {"layer0": f"item/{mat}", "layer1": f"item/{mat}_overlay"}}
    elif mat == 'bow':
        base = {"parent": "item/generated", "textures": {"layer0": "item/bow"},
                "display": {
                    "thirdperson_righthand": {"rotation": [-80, 260, -40], "translation": [-1, -2, 2.5], "scale": [0.9, 0.9, 0.9]},
                    "thirdperson_lefthand": {"rotation": [-80, -280, 40], "translation": [-1, -2, 2.5], "scale": [0.9, 0.9, 0.9]},
                    "firstperson_righthand": {"rotation": [0, -90, 25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
                    "firstperson_lefthand": {"rotation": [0, 90, -25], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]}}}
        overrides += [{"predicate": {"pulling": 1}, "model": "item/bow_pulling_0"},
                      {"predicate": {"pulling": 1, "pull": 0.65}, "model": "item/bow_pulling_1"},
                      {"predicate": {"pulling": 1, "pull": 0.9}, "model": "item/bow_pulling_2"}]
    elif mat == 'crossbow':
        base = {"parent": "item/generated", "textures": {"layer0": "item/crossbow_standby"},
                "display": {
                    "thirdperson_righthand": {"rotation": [-90, 0, -60], "translation": [2, 0.1, -3], "scale": [0.9, 0.9, 0.9]},
                    "thirdperson_lefthand": {"rotation": [-90, 0, 30], "translation": [2, 0.1, -3], "scale": [0.9, 0.9, 0.9]},
                    "firstperson_righthand": {"rotation": [-90, 0, -70], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]},
                    "firstperson_lefthand": {"rotation": [-90, 0, 70], "translation": [1.13, 3.2, 1.13], "scale": [0.68, 0.68, 0.68]}}}
        overrides += [{"predicate": {"pulling": 1}, "model": "item/crossbow_pulling_0"},
                      {"predicate": {"pulling": 1, "pull": 0.58}, "model": "item/crossbow_pulling_1"},
                      {"predicate": {"pulling": 1, "pull": 1.0}, "model": "item/crossbow_pulling_2"},
                      {"predicate": {"charged": 1}, "model": "item/crossbow_arrow"},
                      {"predicate": {"charged": 1, "firework": 1}, "model": "item/crossbow_firework"}]
    elif mat == 'shield':
        base = {"parent": "builtin/entity", "gui_light": "front",
                "display": {"gui": {"rotation": [15, -25, -5], "translation": [2, 3, 0], "scale": [0.65, 0.65, 0.65]},
                            "fixed": {"rotation": [0, 180, -5], "translation": [-2, 4, -5], "scale": [0.5, 0.5, 0.5]},
                            "ground": {"rotation": [0, 0, 0], "translation": [4, 4, 2], "scale": [0.25, 0.25, 0.25]},
                            "thirdperson_righthand": {"rotation": [0, 90, 0], "translation": [10, 6, -4], "scale": [1, 1, 1]},
                            "thirdperson_lefthand": {"rotation": [0, 90, 0], "translation": [10, 6, 12], "scale": [1, 1, 1]},
                            "firstperson_righthand": {"rotation": [0, 180, 5], "translation": [-10, 2, -10], "scale": [1.25, 1.25, 1.25]},
                            "firstperson_lefthand": {"rotation": [0, 180, 5], "translation": [10, 0, -10], "scale": [1.25, 1.25, 1.25]}}}
        overrides += [{"predicate": {"blocking": 1}, "model": "item/shield_blocking"}]
    else:
        base = {"parent": "item/generated", "textures": {"layer0": f"item/{mat}"}}
    for cmd, name in lst:
        overrides.append(ov(cmd, f"gw:item/{name}"))
        if mat == 'bow':
            for i, pr in enumerate((None, 0.65, 0.9)):
                e = {"pulling": 1}
                if pr: e["pull"] = pr
                overrides.append(ov(cmd, f"gw:item/{BOW_ID}_pulling_{i}", e))
    base["overrides"] = overrides
    dump(os.path.join(OUT, 'assets', 'minecraft', 'models', 'item', mat + '.json'), base)

# палитра
img = Image.new('RGBA', (gwmodel.GRID, gwmodel.GRID), (0, 0, 0, 0))
for col, i in gwmodel.PALETTE.items():
    h = col.lstrip('#')
    img.putpixel((i % gwmodel.GRID, i // gwmodel.GRID), (int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 255))
img.save(os.path.join(OUT, 'assets', 'gw', 'textures', 'item', 'palette.png'))

dump(os.path.join(OUT, 'pack.mcmeta'), {"pack": {"pack_format": 15,
     "description": "GWinterhold: 3D-предметы классов"}})
print('models:', len(D), 'bases:', len(by_mat), 'palette colors:', len(gwmodel.PALETTE))
