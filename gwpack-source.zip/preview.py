"""Грубый предпросмотр JSON-моделей Minecraft (ортографическая проекция, как в инвентаре)."""
import math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
from gwmodel import PALETTE, GRID


def rot(axis, deg):
    a = math.radians(deg)
    c, s = math.cos(a), math.sin(a)
    if axis == 'x': return np.array([[1, 0, 0], [0, c, -s], [0, s, c]])
    if axis == 'y': return np.array([[c, 0, s], [0, 1, 0], [-s, 0, c]])
    return np.array([[c, -s, 0], [s, c, 0], [0, 0, 1]])


FACES = {  # вершины граней (индексы углов по битам x,y,z), нормаль
    'north': ((0, 0, 0), (1, 0, 0), (1, 1, 0), (0, 1, 0), (0, 0, -1)),
    'south': ((0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1), (0, 0, 1)),
    'west': ((0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0), (-1, 0, 0)),
    'east': ((1, 0, 0), (1, 0, 1), (1, 1, 1), (1, 1, 0), (1, 0, 0)),
    'down': ((0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1), (0, -1, 0)),
    'up': ((0, 1, 0), (1, 1, 0), (1, 1, 1), (0, 1, 1), (0, 1, 0)),
}


def inv_palette():
    return {v: k for k, v in PALETTE.items()}


def color_of_uv(uv, inv):
    s = 16.0 / GRID
    px = int(uv[0] / s)
    py = int(uv[1] / s)
    return inv.get(py * GRID + px, '#ff00ff')


def hex2rgb(h):
    h = h.lstrip('#')
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4))


def render(model_json, ax, view="gui"):
    d = model_json["display"][view]
    inv = inv_palette()
    R = rot('x', d["rotation"][0]) @ rot('y', d["rotation"][1]) @ rot('z', d["rotation"][2])
    S = np.array(d["scale"])
    T = np.array(d["translation"]) / 16.0
    polys = []
    light = np.array([0.35, 0.85, 0.45]); light /= np.linalg.norm(light)
    for el in model_json["elements"]:
        f, t = np.array(el["from"], float), np.array(el["to"], float)
        er = None
        if "rotation" in el:
            r = el["rotation"]; er = (np.array(r["origin"], float), rot(r["axis"], r["angle"]))
        any_face = next(iter(el["faces"].values()))
        base = hex2rgb(color_of_uv(any_face["uv"], inv))

        def tr(p):
            if er: p = er[0] + er[1] @ (p - er[0])
            p = p / 16.0 - 0.5
            return T + R @ (S * p)

        for name, (a, b, c, dd, n) in FACES.items():
            pts = []
            for corner in (a, b, c, dd):
                p = np.array([f[i] if corner[i] == 0 else t[i] for i in range(3)], float)
                pts.append(tr(p))
            nrm = np.array(n, float)
            if er: nrm = er[1] @ nrm
            nrm = R @ nrm
            if nrm[2] <= 1e-6: continue   # обратная грань
            k = 0.55 + 0.45 * max(0.0, float(np.dot(nrm, light)))
            col = tuple(min(1, v * k) for v in base)
            depth = sum(p[2] for p in pts) / 4
            polys.append((depth, [(p[0], p[1]) for p in pts], col))
    polys.sort(key=lambda x: x[0])
    for _, pts, col in polys:
        ax.add_patch(Polygon(pts, closed=True, facecolor=col, edgecolor=(0, 0, 0, 0.35), linewidth=0.3))
    ax.set_xlim(-0.6, 0.6); ax.set_ylim(-0.6, 0.6); ax.set_aspect('equal'); ax.axis('off')


def sheet(models, path, cols=6, view="gui", titles=True):
    rows = math.ceil(len(models) / cols)
    fig, axes = plt.subplots(rows, cols, figsize=(cols * 2.2, rows * 2.4), facecolor='#202028')
    axes = np.array(axes).reshape(-1)
    for ax in axes: ax.axis('off'); ax.set_facecolor('#202028')
    for ax, (name, mj) in zip(axes, models):
        ax.set_facecolor('#33333d')
        ax.add_patch(plt.Rectangle((-0.6, -0.6), 1.2, 1.2, color='#33333d'))
        render(mj, ax, view)
        if titles: ax.set_title(name, color='white', fontsize=7)
    fig.tight_layout()
    fig.savefig(path, dpi=110, facecolor=fig.get_facecolor())
    plt.close(fig)
