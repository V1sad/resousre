"""36 предметов классов GWinterhold как 3D-модели. Передняя грань брони и щитов - north (малый z)."""
from gwmodel import Model, shade

# ---------- цвета ----------
STEEL, STEEL_D, STEEL_L = '#9aa3ad', '#6b737d', '#cfd6dd'
IRON, IRON_D = '#8a8f96', '#5b6068'
GOLD, GOLD_D, GOLD_L = '#e0b83a', '#a8841c', '#ffe27a'
DIAM, DIAM_D, DIAM_L = '#3fd0d6', '#238e96', '#9ff4f4'
LEATHER, LEATHER_D, LEATHER_L = '#7a4e2c', '#4d2f19', '#a06a3c'
DARK, DARKER = '#26262e', '#14141a'
WOOD, WOOD_D, WOOD_L = '#7b5a35', '#4f391f', '#a47d4c'
WHITE, CREAM = '#f2f2f0', '#e8e0c8'
RED, RED_D = '#c0392b', '#7d2219'
ICE, ICE_D, ICE_L = '#8fd3f4', '#4a9cc8', '#e4f7ff'
PURPLE, PURPLE_D, PURPLE_L = '#8a4fd1', '#4e2a85', '#cda8ff'
GREEN, GREEN_D, GREEN_L = '#4f9d3a', '#2e5f22', '#8fdc6a'
TEAL, TEAL_D, TEAL_L = '#2fb5a3', '#1b6f65', '#8af2e2'
ORANGE, ORANGE_D, ORANGE_L = '#ee7a1a', '#a24a0c', '#ffc266'
BLUE, BLUE_D, BLUE_L = '#3a6fd8', '#223f85', '#9dc0ff'
YELLOW = '#ffe94a'
BONE, BONE_D = '#e9e4d0', '#b3ac90'
VIOLET_GLOW = '#c77dff'
LIME = '#b6ff5a'

RARITY_GLOW = {'RARE': BLUE_L, 'EPIC': PURPLE_L, 'LEGENDARY': ORANGE_L, 'ARTIFACT': GOLD_L}


# ---------- вспомогательное ----------
def gem(m, cx, cy, cz, size, col):
    h = size / 2
    m.box(cx - h, cy - h, cz - h, cx + h, cy + h, cz + h, col)
    m.box(cx - h * 0.5, cy - h * 1.35, cz - h * 0.5, cx + h * 0.5, cy + h * 1.35, cz + h * 0.5, shade(col, 1.15))


def blade(m, x, y0, length, w, thick, col, edge, tip_steps=3):
    """Клинок вверх от y0: основная часть, острие ступенями, долы."""
    body = length - tip_steps * 0.9
    m.box(x - w / 2, y0, 8 - thick / 2, x + w / 2, y0 + body, 8 + thick / 2, col)
    m.box(x - w / 2 + 0.2, y0, 8 - thick / 2 - 0.12, x + w / 2 - 0.2, y0 + body, 8 + thick / 2 + 0.12, edge)
    cur = y0 + body
    ww = w
    for i in range(tip_steps):
        ww = max(0.35, ww * 0.62)
        m.box(x - ww / 2, cur, 8 - thick / 2 + 0.05, x + ww / 2, cur + 0.9, 8 + thick / 2 - 0.05, col)
        cur += 0.9


def sword(blade_col, edge_col, guard_col, grip_col, pommel_col, gem_col=None, length=14.5, width=2.4, thick=1.2,
          guard_w=8.5, wings=None, glow=None):
    m = Model('diag')
    y0 = -3.3
    m.box(7, y0, 7, 9, y0 + 2, 9, pommel_col)
    m.box(7.45, y0 + 2, 7.45, 8.55, y0 + 5.5, 8.55, grip_col)
    for k in range(3):  # обмотка рукояти
        m.box(7.3, y0 + 2.4 + k * 1.1, 7.3, 8.7, y0 + 2.9 + k * 1.1, 8.7, shade(grip_col, 0.7))
    gy = y0 + 5.5
    m.box(8 - guard_w / 2, gy, 6.9, 8 + guard_w / 2, gy + 1.5, 9.1, guard_col)
    m.box(8 - guard_w / 2 - 0.6, gy + 0.3, 7.2, 8 - guard_w / 2, gy + 2.2, 8.8, shade(guard_col, 1.15))
    m.box(8 + guard_w / 2, gy + 0.3, 7.2, 8 + guard_w / 2 + 0.6, gy + 2.2, 8.8, shade(guard_col, 1.15))
    m.box(7, gy + 1.5, 7, 9, gy + 2.2, 9, guard_col)
    if gem_col:
        m.box(7.5, gy + 0.2, 6.6, 8.5, gy + 1.3, 7.0, gem_col)
        m.box(7.5, gy + 0.2, 9.0, 8.5, gy + 1.3, 9.4, gem_col)
    blade(m, 8, gy + 2.2, length, width, thick, blade_col, edge_col)
    if glow:
        m.box(7.85, gy + 3.2, 7.2, 8.15, gy + 2.2 + length - 3, 8.8, glow)
    if wings:
        for s in (-1, 1):
            m.box(8 + s * (guard_w / 2 + 0.6) - 0.5, gy + 1.5, 7.4, 8 + s * (guard_w / 2 + 0.6) + 0.5, gy + 4.2, 8.6, wings)
    return m


def dagger(blade_col, edge_col, guard_col, grip_col, glow=None, length=10, offset=0.0, angle=None):
    m = Model('diag')
    y0 = -1.0
    m.box(7.2, y0, 7.2, 8.8, y0 + 1.5, 8.8, guard_col)
    m.box(7.5, y0 + 1.5, 7.5, 8.5, y0 + 5, 8.5, grip_col)
    for k in range(3):
        m.box(7.35, y0 + 1.7 + k * 1.0, 7.35, 8.65, y0 + 2.1 + k * 1.0, 8.65, shade(grip_col, 0.65))
    m.box(5.8, y0 + 5, 7.2, 10.2, y0 + 6.2, 8.8, guard_col)
    blade(m, 8, y0 + 6.2, length, 2.0, 1.0, blade_col, edge_col, tip_steps=3)
    if glow:
        m.box(7.85, y0 + 7.0, 7.3, 8.15, y0 + 6.2 + length - 2.5, 8.7, glow)
    return m


def axe(head_col, edge_col, haft_col, trim_col, double=False, gem_col=None, length=22):
    m = Model('diag')
    y0 = -3.3
    m.box(7.1, y0, 7.1, 8.9, y0 + 1.5, 8.9, trim_col)
    m.box(7.4, y0 + 1.5, 7.4, 8.6, y0 + length - 3, 8.6, haft_col)
    for k in range(4):
        m.box(7.25, y0 + 3 + k * 1.2, 7.25, 8.75, y0 + 3.5 + k * 1.2, 8.75, shade(haft_col, 0.65))
    hy = y0 + length - 8.5
    # голова: ступенчатые лезвия
    steps = [(1.0, 5.0), (2.4, 4.6), (3.6, 3.8), (4.5, 2.8)]
    for side in ((1, -1) if double else (1,)):
        for k, (reach, hgt) in enumerate(steps):
            xa = 8 + side * 0.8
            xb = 8 + side * (0.8 + reach + 0.8)
            m.box(min(xa, xb), hy + (5.0 - hgt) / 2 + 1.5, 7.2, max(xa, xb), hy + (5.0 - hgt) / 2 + 1.5 + hgt, 8.8, head_col if k < 3 else edge_col)
        m.box(min(8 + side * 5.0, 8 + side * 5.6), hy + 2.6, 7.35, max(8 + side * 5.0, 8 + side * 5.6), hy + 5.8, 8.65, edge_col)
    m.box(6.6, hy + 1.0, 6.9, 9.4, hy + 7.0, 9.1, trim_col)
    if not double:
        m.box(6.8, hy + 6.5, 7.2, 9.2, hy + 8.8, 8.8, trim_col)   # пика сверху
        m.box(7.5, hy + 8.8, 7.5, 8.5, hy + 10.5, 8.5, edge_col)
    else:
        m.box(7.3, hy + 7.0, 7.3, 8.7, hy + 9.5, 8.7, edge_col)
    if gem_col:
        gem(m, 8, hy + 4.0, 6.8, 1.4, gem_col)
        gem(m, 8, hy + 4.0, 9.2, 1.4, gem_col)
    return m


def staff(shaft, shaft_d, head, accent=None, orb=None, forked=False, length=22, twisted=False):
    m = Model('diag')
    y0 = -3.3
    m.box(7.3, y0, 7.3, 8.7, y0 + 1.2, 8.7, shade(shaft_d, 0.8))
    m.box(7.5, y0 + 1.2, 7.5, 8.5, y0 + length - 5, 8.5, shaft)
    for k in range(5):
        off = 0.25 * (k % 2 if twisted else 0)
        m.box(7.35 + off, y0 + 3 + k * 2.6, 7.35, 8.65 + off, y0 + 3.6 + k * 2.6, 8.65, shaft_d)
    top = y0 + length - 5
    m.box(6.9, top - 0.5, 6.9, 9.1, top + 0.7, 9.1, accent or shaft_d)
    if forked:  # рогатина
        for s in (-1, 1):
            m.box(8 + s * 1.2 - 0.5, top + 0.7, 7.5, 8 + s * 1.2 + 0.5, top + 3.0, 8.5, shaft)
            m.box(8 + s * 2.1 - 0.5, top + 2.2, 7.5, 8 + s * 2.1 + 0.5, top + 5.0, 8.5, shaft)
            m.box(8 + s * 2.6 - 0.45, top + 4.5, 7.5, 8 + s * 2.6 + 0.45, top + 6.0, 8.5, shaft_d)
        if orb:
            gem(m, 8, top + 3.2, 8, 2.2, orb)
    else:
        for s in (-1, 1):
            m.box(8 + s * 1.5 - 0.35, top + 0.7, 7.65, 8 + s * 1.5 + 0.35, top + 3.5, 8.35, accent or head)
        if orb:
            m.box(6.6, top + 1.4, 6.6, 9.4, top + 4.2, 9.4, orb)
            m.box(6.0, top + 2.0, 7.2, 10.0, top + 3.6, 8.8, orb)
            m.box(7.2, top + 2.0, 6.0, 8.8, top + 3.6, 10.0, orb)
            m.box(7.2, top + 4.2, 7.2, 8.8, top + 5.0, 8.8, head)
            m.box(7.2, top + 0.7, 7.2, 8.8, top + 1.4, 8.8, head)
    return m


def mace(head, head_d, haft, trim, glow):
    m = Model('diag')
    y0 = -3.3
    m.box(7.3, y0, 7.3, 8.7, y0 + 1.2, 8.7, trim)
    m.box(7.5, y0 + 1.2, 7.5, 8.5, y0 + 14, 8.5, haft)
    for k in range(4):
        m.box(7.35, y0 + 3 + k * 2.2, 7.35, 8.65, y0 + 3.6 + k * 2.2, 8.65, shade(haft, 0.6))
    hy = y0 + 14
    m.box(5.8, hy, 5.8, 10.2, hy + 5.2, 10.2, head)
    m.box(5.2, hy + 1.1, 6.6, 10.8, hy + 4.1, 9.4, head_d)
    m.box(6.6, hy + 1.1, 5.2, 9.4, hy + 4.1, 10.8, head_d)
    m.box(7, hy + 5.2, 7, 9, hy + 6.8, 9, head)
    m.box(7.5, hy + 6.8, 7.5, 8.5, hy + 8.2, 8.5, glow)
    m.box(6.9, hy - 1.0, 6.9, 9.1, hy, 9.1, trim)
    # молнии по бокам
    for s in (-1, 1):
        m.box(8 + s * 3.4 - 0.4, hy + 0.8, 5.6, 8 + s * 3.4 + 0.4, hy + 4.2, 6.0, glow)
    return m


def bone_wand(bone, bone_d, glow, skull=True):
    m = Model('diag')
    y0 = -3.3
    m.box(7.0, y0, 7.0, 9.0, y0 + 1.8, 9.0, bone)
    m.box(6.2, y0 - 0.3, 7.0, 7.4, y0 + 0.9, 9.0, bone)
    m.box(8.6, y0 - 0.3, 7.0, 9.8, y0 + 0.9, 9.0, bone)
    m.box(7.45, y0 + 1.8, 7.45, 8.55, y0 + 14, 8.55, bone)
    for k in range(5):
        m.box(7.3, y0 + 3 + k * 2.1, 7.3, 8.7, y0 + 3.5 + k * 2.1, 8.7, bone_d)
    top = y0 + 14
    if skull:
        m.box(6.2, top, 6.5, 9.8, top + 3.6, 9.5, bone)
        m.box(6.6, top + 3.6, 6.8, 9.4, top + 4.6, 9.2, bone)
        m.box(6.6, top + 1.7, 6.35, 7.6, top + 2.7, 6.55, DARKER)
        m.box(8.4, top + 1.7, 6.35, 9.4, top + 2.7, 6.55, DARKER)
        m.box(7.6, top + 1.9, 6.3, 8.4, top + 2.5, 6.45, glow)
        m.box(6.9, top - 0.8, 6.9, 9.1, top, 9.1, bone_d)
        m.box(7.8, top + 4.6, 7.8, 8.2, top + 6.4, 8.2, glow)
    return m


def bow(wood, wood_d, accent, string='#efefef', glow=None, pull=0.0):
    m = Model('diag')
    # вертикальный лук, тетива справа; дуга влево
    pts = [(5.4, 10), (4.6, 12), (4.0, 14), (3.8, 16), (4.0, 18), (4.6, 20), (5.6, 21.2)]
    y_c = 8
    for (x, y) in pts:                       # верхняя половина
        m.box(x - 0.8, y - 1.1, 7.2, x + 0.8, y + 1.1, 8.8, wood)
    for (x, y) in pts:                       # нижняя - зеркально относительно y=8 (центр лука 8)
        m.box(x - 0.8, 16 - y - 1.1, 7.2, x + 0.8, 16 - y + 1.1, 8.8, wood)
    m.box(4.6, 6.3, 6.9, 8.6, 9.7, 9.1, accent)       # рукоять
    m.box(5.0, 7.0, 6.6, 8.2, 9.0, 9.4, wood_d)
    for yy in (21.4, -5.4):
        m.box(5.6, yy - 0.5, 7.0, 7.0, yy + 0.5, 9.0, accent)
    if pull <= 0:
        m.box(6.9, -4.8, 7.75, 7.15, 20.8, 8.25, string)   # тетива
    else:                                                  # натянутая тетива ломаной вниз-влево
        for k in range(13):
            y = 20.8 - k * 1.0
            x = 6.9 - pull * (1 - abs(y - 8) / 12.8)
            m.box(x, y - 1.0, 7.75, x + 0.3, y, 8.25, string)
        for k in range(13):
            y = -4.8 + k * 1.0
            x = 6.9 - pull * (1 - abs(y + 1 - 8) / 12.8)
            m.box(x, y, 7.75, x + 0.3, y + 1.0, 8.25, string)
        m.box(6.9 - pull - 0.4, 7.5, 7.7, 8.5, 8.5, 8.3, WOOD_D)   # стрела
    if glow:
        m.box(4.2, 12.0, 6.9, 5.2, 13.0, 9.1, glow)
        m.box(4.2, 3.0, 6.9, 5.2, 4.0, 9.1, glow)
        m.box(3.2, 15.5, 7.0, 4.2, 16.5, 9.0, glow)
    return m


def crossbow(wood, wood_d, metal, glow, string='#efefef'):
    m = Model('diag')
    # ложе вертикально (ствол вверх), дуга поперёк
    m.box(7.0, -3, 7.0, 9.0, 3, 9.0, wood_d)
    m.box(7.2, 3, 7.0, 8.8, 19, 9.0, wood)
    m.box(7.45, 3, 6.7, 8.55, 19, 7.0, metal)
    m.box(6.8, 9, 6.8, 9.2, 11, 9.2, metal)
    # дуга
    m.box(2.0, 14.8, 7.0, 14.0, 16.2, 9.0, wood_d)
    m.box(1.0, 15.4, 7.0, 2.4, 17.6, 9.0, wood)
    m.box(13.6, 15.4, 7.0, 15.0, 17.6, 9.0, wood)
    m.box(1.4, 12.5, 7.7, 2.0, 15.5, 8.3, string)
    m.box(14.0, 12.5, 7.7, 14.6, 15.5, 8.3, string)
    m.box(1.4, 12.5, 7.7, 8.0, 13.1, 8.3, string)
    m.box(8.0, 12.5, 7.7, 14.6, 13.1, 8.3, string)
    m.box(7.5, 17.0, 7.5, 8.5, 19.8, 8.5, metal)
    if glow:
        gem(m, 8, 11.2, 6.5, 1.8, glow)
        gem(m, 8, 6.0, 6.5, 1.4, glow)
        m.box(7.7, 19.8, 7.7, 8.3, 21.5, 8.3, glow)
    return m


def shield(field, border, emblem, rim_d, boss=None):
    m = Model('shield')
    # прямоугольный щит-башня, лицевая сторона north (малый z)
    m.box(2.5, 0.5, 6.2, 13.5, 15.5, 8.0, field)
    m.box(3.5, -1.0, 6.4, 12.5, 0.5, 7.8, field)
    m.box(5.0, -2.2, 6.6, 11.0, -1.0, 7.6, field)
    m.box(2.0, 0.5, 5.8, 3.3, 15.5, 8.2, border)
    m.box(12.7, 0.5, 5.8, 14.0, 15.5, 8.2, border)
    m.box(2.0, 14.3, 5.8, 14.0, 15.8, 8.2, border)
    m.box(3.0, -1.4, 5.9, 4.0, 0.5, 8.0, border)
    m.box(12.0, -1.4, 5.9, 13.0, 0.5, 8.0, border)
    m.box(5.0, -2.6, 6.0, 11.0, -1.6, 7.8, border)
    m.box(7.2, 2.0, 5.5, 8.8, 14.0, 6.3, emblem)       # вертикаль креста
    m.box(4.2, 8.5, 5.5, 11.8, 10.0, 6.3, emblem)       # горизонталь
    if boss:
        gem(m, 8, 9.2, 5.1, 2.2, boss)
    m.box(7.0, 4.0, 8.0, 9.0, 12.0, 8.9, rim_d)         # ручка сзади
    m.box(5.0, 7.5, 8.0, 11.0, 8.5, 9.4, rim_d)
    return m


def tome(cover, trim, pages, glow, spine=None):
    m = Model('offhand')
    m.box(2.5, 1.0, 4.0, 13.5, 4.0, 12.0, cover)           # книга лежит корешком вдоль
    m.box(3.0, 1.5, 4.4, 13.0, 3.5, 11.6, pages)
    m.box(2.5, 1.0, 4.0, 3.5, 4.0, 12.0, spine or trim)
    m.box(13.5, 1.0, 4.0, 13.7, 4.0, 12.0, trim)
    m.box(2.5, 4.0, 3.9, 13.5, 4.9, 12.1, cover)           # верхняя крышка
    m.box(2.5, 0.1, 3.9, 13.5, 1.0, 12.1, cover)
    m.box(3.0, 4.9, 4.4, 13.0, 5.2, 11.6, trim)
    m.box(7.0, 5.2, 6.5, 9.0, 5.6, 9.5, glow)               # эмблема
    m.box(7.7, 5.2, 5.0, 8.3, 5.6, 11.0, glow)
    m.box(4.2, 5.2, 7.7, 11.8, 5.6, 8.3, glow)
    return m


def crystal(core, light, dark, base, n=5):
    m = Model('offhand')
    m.box(4.5, 0.0, 4.5, 11.5, 1.6, 11.5, base)
    m.box(5.2, 1.6, 5.2, 10.8, 2.4, 10.8, shade(base, 0.8))
    big = [(8, 8, 3.4, 11.5), (5.6, 6.2, 2.2, 8.0), (10.4, 9.2, 2.4, 7.5), (7.2, 10.6, 1.8, 6.0), (9.8, 5.6, 1.9, 5.5)]
    for (x, z, w, h) in big[:n]:
        m.box(x - w / 2, 2.4, z - w / 2, x + w / 2, 2.4 + h, z + w / 2, core)
        m.box(x - w / 2 + 0.3, 2.4 + h, z - w / 2 + 0.3, x + w / 2 - 0.3, 2.4 + h + 0.9, z + w / 2 - 0.3, light)
        m.box(x - w / 4, 2.4 + h + 0.9, z - w / 4, x + w / 4, 2.4 + h + 1.7, z + w / 4, light)
        m.box(x - w / 2 - 0.05, 2.4, z - w / 2 - 0.05, x - w / 2 + 0.25, 2.4 + h * 0.8, z + w / 2 + 0.05, dark)
    return m


def orb(core, light, ring, stand, swirl=None):
    m = Model('offhand')
    m.box(5.5, 0.0, 5.5, 10.5, 1.0, 10.5, stand)
    m.box(6.5, 1.0, 6.5, 9.5, 2.0, 9.5, shade(stand, 1.2))
    m.box(4.6, 2.0, 4.6, 11.4, 11.0, 11.4, core)          # сфера из слоёв
    m.box(3.6, 3.4, 3.6, 12.4, 9.6, 12.4, core)
    m.box(5.4, 11.0, 5.4, 10.6, 12.4, 10.6, core)
    m.box(5.6, 1.4, 5.6, 10.4, 2.0, 10.4, shade(core, 0.8))
    m.box(4.6, 7.0, 3.3, 7.8, 9.6, 3.8, light)             # блик
    m.box(3.4, 6.0, 3.4, 12.6, 6.7, 12.6, ring)
    m.box(2.8, 6.1, 2.8, 13.2, 6.6, 13.2, ring)
    if swirl:
        m.box(6.0, 6.0, 3.6, 7.5, 7.0, 4.0, swirl)
        m.box(7.5, 3.2, 3.6, 9.5, 4.2, 4.0, swirl)
    return m


def shard(core, light, dark, glow, floaters=True):
    m = Model('offhand')
    # центральный осколок: ромбовидный столбик
    m.box(6.5, 2.0, 6.5, 9.5, 12.0, 9.5, core)
    m.box(7.0, 12.0, 7.0, 9.0, 13.6, 9.0, light)
    m.box(7.5, 13.6, 7.5, 8.5, 14.8, 8.5, light)
    m.box(7.0, 0.8, 7.0, 9.0, 2.0, 9.0, dark)
    m.box(7.5, 0.0, 7.5, 8.5, 0.8, 8.5, dark)
    m.box(6.3, 4.0, 6.3, 6.7, 10.0, 9.7, dark)
    m.box(7.2, 4.0, 6.2, 8.8, 11.0, 6.5, glow)
    if floaters:
        for (x, y, z, s) in ((3.5, 9.0, 5.0, 1.8), (12.0, 7.0, 10.5, 1.5), (10.8, 12.0, 4.0, 1.2), (4.5, 3.5, 11.0, 1.3)):
            m.box(x - s / 2, y, z - s / 2, x + s / 2, y + s * 1.8, z + s / 2, core)
            m.box(x - s / 4, y + s * 1.8, z - s / 4, x + s / 4, y + s * 2.4, z + s / 4, light)
    return m


def seed(shell, shell_d, glow, leaf, leaf_d, soil):
    m = Model('offhand')
    m.box(4.0, 0.0, 4.0, 12.0, 1.5, 12.0, soil)
    m.box(5.0, 1.5, 5.0, 11.0, 2.2, 11.0, shade(soil, 0.85))
    m.box(5.0, 2.2, 5.0, 11.0, 8.0, 11.0, shell)           # семя
    m.box(5.8, 8.0, 5.8, 10.2, 9.4, 10.2, shell)
    m.box(4.2, 3.0, 4.2, 5.0, 7.0, 11.8, shell_d)
    m.box(11.0, 3.0, 4.2, 11.8, 7.0, 11.8, shell_d)
    m.box(7.1, 3.2, 4.6, 8.9, 8.6, 5.0, glow)              # светящийся шов
    m.box(7.6, 4.2, 4.5, 8.4, 7.6, 4.8, '#e8fff2')
    m.box(7.5, 9.4, 7.5, 8.5, 12.2, 8.5, leaf_d)           # росток
    m.box(8.5, 11.0, 7.2, 12.5, 12.0, 8.8, leaf)
    m.box(11.5, 11.8, 7.4, 13.5, 12.8, 8.6, leaf)
    m.box(3.5, 12.0, 7.2, 7.5, 13.0, 8.8, leaf)
    m.box(2.5, 12.8, 7.4, 4.5, 13.8, 8.6, leaf)
    m.box(7.2, 12.2, 7.2, 8.8, 14.0, 8.8, leaf_d)
    return m


# ---------- броня ----------
def helmet(base, trim, visor=DARK, crest=None, horns=None, cheeks=True, hood=False, glow_eyes=None, shell=False):
    m = Model('upright')
    m.box(3.2, 2.0, 3.2, 12.8, 10.6, 12.8, base)                   # купол
    m.box(4.2, 10.6, 4.2, 11.8, 11.8, 11.8, base)
    m.box(5.4, 11.8, 5.4, 10.6, 12.6, 10.6, shade(base, 1.12))
    m.box(3.0, 6.2, 3.0, 13.0, 7.6, 13.0, trim)                      # обод
    m.box(3.0, 2.0, 3.0, 13.0, 3.0, 13.0, shade(trim, 0.9))
    if not hood:
        m.box(4.4, 3.2, 2.9, 11.6, 6.0, 3.2, visor)                 # прорезь забрала спереди (north)
        m.box(7.3, 3.2, 2.8, 8.7, 9.6, 3.2, shade(trim, 0.95))      # налобная планка
        if glow_eyes:
            m.box(5.0, 4.4, 2.75, 6.6, 5.2, 2.95, glow_eyes)
            m.box(9.4, 4.4, 2.75, 11.0, 5.2, 2.95, glow_eyes)
    else:
        m.box(4.4, 3.4, 2.9, 11.6, 6.4, 3.3, DARKER)
        m.box(3.5, 6.0, 2.8, 12.5, 7.0, 3.3, base)
        if glow_eyes:
            m.box(5.0, 4.4, 2.7, 6.6, 5.2, 2.95, glow_eyes)
            m.box(9.4, 4.4, 2.7, 11.0, 5.2, 2.95, glow_eyes)
    if cheeks:
        m.box(3.0, 2.0, 3.2, 4.4, 6.0, 8.4, shade(base, 0.92))
        m.box(11.6, 2.0, 3.2, 13.0, 6.0, 8.4, shade(base, 0.92))
    if crest:
        m.box(7.3, 12.6, 3.2, 8.7, 14.2, 12.8, crest)
        m.box(7.3, 11.8, 2.6, 8.7, 13.0, 4.2, crest)
    if horns:
        for s in (-1, 1):
            m.box(8 + s * 5.1 - 0.7, 8.0, 7.3, 8 + s * 5.1 + 0.7, 10.0, 8.7, horns)
            m.box(8 + s * 5.9 - 0.6, 10.0, 7.4, 8 + s * 5.9 + 0.6, 12.2, 8.6, horns)
            m.box(8 + s * 6.4 - 0.45, 12.2, 7.5, 8 + s * 6.4 + 0.45, 14.0, 8.5, shade(horns, 1.15))
    if shell:
        for k in range(3):
            m.box(5.0 + k * 2.0, 11.8, 5.0, 6.2 + k * 2.0, 12.8, 11.0, shade(base, 0.8 + 0.15 * k))
    return m


def chest(base, trim, accent=None, pauldron=None, belt=None, robe=False, cloak=None, emblem=None, sleeves=True):
    m = Model('upright')
    m.box(3.4, 3.0, 4.6, 12.6, 14.0, 11.4, base)                    # торс
    m.box(3.2, 1.0 if not robe else -1.0, 4.4, 12.8, 3.0, 11.6, shade(base, 0.9))   # нижний край
    m.box(5.6, 13.0, 4.8, 10.4, 14.4, 11.2, shade(trim, 1.0))       # ворот
    if sleeves:
        m.box(0.6, 8.6, 4.8, 3.4, 14.0, 11.2, base)
        m.box(12.6, 8.6, 4.8, 15.4, 14.0, 11.2, base)
        m.box(0.8, 5.0, 5.2, 3.2, 8.6, 10.8, shade(base, 0.92))
        m.box(12.8, 5.0, 5.2, 15.2, 8.6, 10.8, shade(base, 0.92))
        m.box(0.6, 4.2, 5.0, 3.4, 5.4, 11.0, trim)
        m.box(12.6, 4.2, 5.0, 15.4, 5.4, 11.0, trim)
    if pauldron:
        m.box(0.0, 13.6, 4.2, 4.0, 15.4, 11.8, pauldron)
        m.box(12.0, 13.6, 4.2, 16.0, 15.4, 11.8, pauldron)
        m.box(0.4, 15.4, 5.0, 3.6, 16.2, 11.0, shade(pauldron, 1.15))
        m.box(12.4, 15.4, 5.0, 15.6, 16.2, 11.0, shade(pauldron, 1.15))
    if belt:
        m.box(3.2, 4.2, 4.4, 12.8, 5.8, 11.6, belt)
        m.box(7.0, 4.0, 4.2, 9.0, 6.0, 4.5, trim)
    m.box(3.4, 11.4, 4.45, 12.6, 12.0, 4.7, trim)                   # перевязь на груди
    if emblem:
        m.box(7.2, 7.0, 4.3, 8.8, 11.0, 4.6, emblem)
        m.box(6.0, 8.6, 4.3, 10.0, 9.8, 4.6, emblem)
    if accent:
        m.box(4.0, 6.5, 4.4, 6.2, 11.0, 4.7, accent)
        m.box(9.8, 6.5, 4.4, 12.0, 11.0, 4.7, accent)
    if cloak:
        m.box(3.4, 1.0, 11.4, 12.6, 15.0, 12.4, cloak)
        m.box(3.0, -1.0, 11.4, 13.0, 1.0, 12.4, shade(cloak, 0.85))
    return m


def legs(base, trim, belt=None, plate=None, emblem=None, robe=False, runes=None):
    m = Model('upright')
    m.box(3.4, 11.0, 4.6, 12.6, 15.0, 11.4, base)                   # пояс/таз
    m.box(3.2, 10.6, 4.4, 12.8, 12.2, 11.6, trim)
    m.box(3.6, 0.8, 4.8, 7.8, 11.0, 11.2, base)                      # левая нога
    m.box(8.2, 0.8, 4.8, 12.4, 11.0, 11.2, base)                     # правая
    m.box(3.4, 0.0, 4.6, 7.8, 1.2, 11.4, trim)
    m.box(8.2, 0.0, 4.6, 12.6, 1.2, 11.4, trim)
    m.box(7.7, 0.8, 5.2, 8.3, 11.0, 10.8, shade(base, 0.7))          # шов между ногами
    if robe:
        m.box(3.2, -1.0, 4.4, 12.8, 2.0, 11.6, shade(base, 0.9))
    if plate:
        m.box(3.6, 6.2, 4.4, 7.8, 10.6, 4.8, plate)
        m.box(8.2, 6.2, 4.4, 12.4, 10.6, 4.8, plate)
        m.box(3.4, 5.4, 4.3, 7.8, 6.4, 4.9, trim)
        m.box(8.2, 5.4, 4.3, 12.6, 6.4, 4.9, trim)
    if belt:
        m.box(3.2, 12.2, 4.3, 12.8, 13.8, 11.7, belt)
        m.box(7.0, 12.0, 4.0, 9.0, 14.0, 4.4, trim)
    if emblem:
        m.box(7.2, 14.0, 4.3, 8.8, 14.8, 4.6, emblem)
        m.box(7.5, 7.5, 4.3, 8.5, 11.0, 4.6, emblem)
    if runes:
        for (x, y) in ((5.2, 8.0), (10.2, 5.0), (5.4, 3.5), (10.4, 9.2)):
            m.box(x, y, 4.3, x + 1.2, y + 1.8, 4.6, runes)
            m.box(x - 0.4, y + 0.6, 4.3, x + 1.6, y + 1.1, 4.6, runes)
    return m


def boots(base, trim, sole=DARK, wing=None, star=None, roots=None, cuff=True, toe=None):
    m = Model('upright')
    for x0 in (2.2, 8.4):
        m.box(x0, 0.0, 3.4, x0 + 5.4, 1.6, 10.8, sole)                 # подошва (удлинена вперёд)
        m.box(x0 + 0.2, 1.6, 3.8, x0 + 5.2, 6.0, 10.6, base)           # носок и голенище
        m.box(x0 + 0.4, 6.0, 6.2, x0 + 5.0, 11.5, 10.6, base)          # высокое голенище
        if cuff:
            m.box(x0 - 0.1, 10.0, 6.0, x0 + 5.5, 11.8, 10.9, trim)
        m.box(x0 + 0.2, 3.0, 3.6, x0 + 5.2, 4.2, 6.4, shade(trim, 0.95))
        if toe:
            m.box(x0 + 0.6, 1.6, 3.2, x0 + 4.8, 3.2, 3.8, toe)
    if wing:
        for x0 in (1.4, 14.2):
            m.box(x0, 5.5, 7.5, x0 + 0.5, 9.5, 9.5, wing)
            m.box(x0 - (0.6 if x0 < 8 else -0.5), 8.0, 7.7, x0 + 0.5, 11.0, 9.3, wing)
    if star:
        for x0 in (4.9, 11.1):
            m.box(x0 - 0.6, 7.4, 3.6, x0 + 0.6, 8.6, 3.9, star)
            m.box(x0 - 0.2, 6.9, 3.6, x0 + 0.2, 9.1, 3.9, star)
    if roots:
        for x0 in (2.0, 8.2):
            m.box(x0, 1.6, 2.8, x0 + 1.0, 2.8, 4.0, roots)
            m.box(x0 + 4.6, 1.6, 3.0, x0 + 5.6, 3.2, 4.2, roots)
            m.box(x0 + 1.0, 6.5, 6.0, x0 + 4.4, 7.4, 6.4, roots)
            m.box(x0 + 2.2, 4.5, 6.1, x0 + 3.0, 6.5, 6.5, roots)
    return m


# ---------- каталог ----------
def build_all():
    D = {}
    # --- Воин ---
    D['warrior_rare_helm'] = helmet(STEEL, STEEL_D, visor=DARKER, crest=RED, cheeks=True)
    D['warrior_epic_chest'] = chest(DIAM, DIAM_D, accent=DIAM_L, pauldron=STEEL, belt=GOLD_D, emblem=GOLD)
    D['warrior_leg_axe'] = axe(STEEL, STEEL_L, WOOD_D, GOLD, double=True, gem_col=ORANGE_L)
    D['warrior_art_sword'] = sword(ICE, ICE_L, STEEL_D, DARK, STEEL, gem_col=ICE_L, length=15.5, width=3.0,
                                   guard_w=9.5, wings=ICE, glow='#ffffff')
    # --- Паладин ---
    D['paladin_rare_boots'] = boots(STEEL, GOLD, sole=GOLD_D, wing=WHITE)
    D['paladin_epic_legs'] = legs(WHITE, GOLD, belt=GOLD_D, plate=STEEL_L, emblem=GOLD_L)
    D['paladin_leg_sword'] = sword(GOLD_L, WHITE, GOLD, LEATHER_D, GOLD, gem_col=YELLOW, length=15, width=2.6,
                                   guard_w=9.5, wings=WHITE, glow=YELLOW)
    D['paladin_art_shield'] = shield(WHITE, GOLD, GOLD, GOLD_D, boss=YELLOW)
    # --- Охотник ---
    D['hunter_rare_helm'] = helmet(GREEN_D, LEATHER, visor=DARKER, hood=True, cheeks=False, crest=GREEN_L)
    D['hunter_epic_chest'] = chest(GREEN, GREEN_D, accent=GREEN_L, pauldron=LEATHER, belt=LEATHER_D)
    D['hunter_leg_bow'] = bow(WOOD_L, WOOD_D, ICE_L, glow=ICE)
    D['hunter_art_crossbow'] = crossbow(DARK, DARKER, GOLD, LIME)
    # --- Разбойник ---
    D['rogue_rare_boots'] = boots(LEATHER_D, DARK, sole=DARKER, cuff=True)
    D['rogue_epic_legs'] = legs(PURPLE_D, DARK, belt=DARKER, runes=PURPLE_L)
    D['rogue_leg_dagger'] = dagger(DARK, PURPLE, GOLD_D, DARKER, glow=PURPLE_L)
    # --- Жрец ---
    D['priest_rare_helm'] = helmet(CREAM, GOLD, hood=True, cheeks=False, visor=WHITE)
    D['priest_epic_chest'] = chest(WHITE, GOLD, accent=GOLD_L, belt=GOLD, robe=True, emblem=GOLD_L, sleeves=True)
    D['priest_leg_staff'] = staff(WOOD_L, WOOD_D, GOLD, accent=GOLD, orb=YELLOW)
    D['priest_art_tome'] = tome(WHITE, GOLD, CREAM, YELLOW, spine=GOLD_D)
    # --- Шаман ---
    D['shaman_rare_helm'] = helmet(TEAL_D, TEAL_L, visor=DARKER, shell=True, cheeks=False, crest=None)
    D['shaman_epic_chest'] = chest(BLUE_D, BLUE_L, accent=YELLOW, pauldron=TEAL, belt=LEATHER, cloak=BLUE)
    D['shaman_leg_mace'] = mace(STEEL, STEEL_D, WOOD_D, GOLD_D, YELLOW)
    D['shaman_art_heart'] = orb(BLUE, BLUE_L, GOLD, STEEL_D, swirl=WHITE)
    # --- Маг ---
    D['mage_rare_boots'] = boots(PURPLE_D, GOLD, sole=DARK, star=YELLOW)
    D['mage_epic_chest'] = chest(ICE_D, ICE_L, accent=WHITE, pauldron=ICE, belt=BLUE_D, robe=True, emblem=WHITE)
    D['mage_leg_rod'] = staff(ORANGE_D, RED_D, ORANGE, accent=ORANGE_L, orb=ORANGE_L, twisted=True, length=22)
    D['mage_art_crystal'] = crystal(PURPLE, PURPLE_L, PURPLE_D, DARK)
    # --- Чернокнижник ---
    D['warlock_rare_helm'] = helmet(DARK, PURPLE_D, visor=DARKER, hood=True, cheeks=False, horns=BONE_D,
                                    glow_eyes=LIME)
    D['warlock_epic_legs'] = legs(DARK, PURPLE_D, belt=DARKER, runes=VIOLET_GLOW, robe=True)
    D['warlock_leg_bone'] = bone_wand(BONE, BONE_D, LIME)
    D['warlock_art_shard'] = shard('#1f6f78', TEAL_L, '#0b2f34', LIME)
    # --- Друид ---
    D['druid_rare_chest'] = chest(GREEN_D, GREEN, accent=GREEN_L, pauldron=GREEN, belt=LEATHER, cloak=GREEN_D)
    D['druid_epic_boots'] = boots(WOOD, GREEN, sole=WOOD_D, roots=GREEN_L, cuff=True)
    D['druid_leg_staff'] = staff(WOOD, WOOD_D, GREEN, accent=GREEN, orb=GREEN_L, forked=True, twisted=True)
    D['druid_art_seed'] = seed(TEAL_D, '#124a44', TEAL_L, GREEN, GREEN_D, LEATHER_D)
    # --- Остальные клинки (после основных, чтобы сохранить порядок цветов) ---
    D['rogue_art_blades'] = None  # собирается отдельно (два клинка)
    return D


def twin_blades():
    """Два скрещённых клинка: 2 модели 'diag' не сложить - строим один upright-предмет."""
    m = Model('upright')
    for sgn in (-1, 1):
        ang = 22.5 * sgn
        origin = [8, 8, 8]
        rot = ('z', ang, origin)
        m.box(7.3, 0.0, 7.3, 8.7, 1.8, 8.7, LEATHER_D, rot)           # рукоять
        m.box(6.0, 1.8, 7.0, 10.0, 3.0, 9.0, GOLD_D, rot)             # гарда
        m.box(7.0, 3.0, 7.5, 9.0, 12.5, 8.5, ICE_L, rot)              # клинок
        m.box(7.4, 3.0, 7.3, 8.6, 12.5, 8.7, ICE, rot)
        m.box(7.35, 12.5, 7.6, 8.65, 14.0, 8.4, ICE_L, rot)
        m.box(7.75, 14.0, 7.7, 8.25, 15.0, 8.3, WHITE, rot)
    m.box(7.2, 6.5, 7.0, 8.8, 7.8, 9.0, GOLD)                         # скрепление в центре
    return m
